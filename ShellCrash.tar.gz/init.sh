#!/bin/sh
# Copyright (C) Juewuy

#特殊固件识别及标记
[ -f "/etc/storage/started_script.sh" ] && { #老毛子固件
    systype=Padavan 
    initdir='/etc/storage/started_script.sh'
}
[ -d "/jffs" ] && { #华硕固件
    systype=asusrouter
    [ -f "/jffs/.asusrouter" ] && initdir='/jffs/.asusrouter'
    [ -d "/jffs/scripts" ] && initdir='/jffs/scripts/nat-start'
    #华硕启用jffs
    nvram set jffs2_scripts="1"
    nvram commit
}
[ -f "/data/etc/crontabs/root" ] && systype=mi_snapshot #小米设备
[ -w "/var/mnt/cfg/firewall" ] && systype=ng_snapshot   #NETGEAR设备
#容器内环境
grep -qE '/(docker|lxc|kubepods|crio|containerd)/' /proc/1/cgroup 2>/dev/null || [ -f /run/.containerenv ] || [ -f /.dockerenv ] && systype='container'
#检查环境变量
[ "$systype" = 'container' ] && [ -z "$CRASHDIR" ] && [ -z "$clashdir" ] && CRASHDIR='/etc/ShellCrash'
[ -z "$CRASHDIR" ] && [ -n "$clashdir" ] && CRASHDIR="$clashdir"
[ -z "$CRASHDIR" ] && [ -d /tmp/SC_tmp ] && . /tmp/SC_tmp/menus/set_crashdir.sh && set_crashdir
CRASHDIR=$(echo "$CRASHDIR" | sed 's#/*$##') #删除末尾的/
TASKCFGDIR="$CRASHDIR"/configs/task
#移动文件
mkdir -p "$CRASHDIR"
mkdir -p "$TASKCFGDIR"
rm -rf /tmp/SC_tmp/menus/set_crashdir.sh
mv -f /tmp/SC_tmp/* "$CRASHDIR" 2>/dev/null
##############################
#注意目录变更
CFG_PATH="$CRASHDIR"/configs/ShellCrash.cfg
# 兼容 V4 (1.9.7-hardened.2) 运行态升级：V4 写入 0 字节空 .upg_txn/pending 后调用新版 init.sh，
# 在此处将调用链父进程/祖父进程 PID 补写入 pending，防止后续 start.sh start 被误判为崩溃中断而静默回滚
if [ -f "$CRASHDIR/.upg_txn/pending" ] && [ ! -s "$CRASHDIR/.upg_txn/pending" ]; then
    _v4_gppid=$(awk '/^PPid:/{print $2}' "/proc/$PPID/status" 2>/dev/null || true)
    _v4_ggppid=""
    [ -n "$_v4_gppid" ] && _v4_ggppid=$(awk '/^PPid:/{print $2}' "/proc/$_v4_gppid/status" 2>/dev/null || true)
    printf '%s\n%s\n%s\n' "$PPID" "$_v4_gppid" "$_v4_ggppid" >"$CRASHDIR/.upg_txn/pending" 2>/dev/null || true
fi
. "$CRASHDIR"/libs/set_config.sh
. "$CRASHDIR"/libs/set_profile.sh
#初始化（先完成历史配置文件改名与旧键迁移，确保后续 COMMAND 与 systemd 单元生成读取到规范值）
mkdir -p "$CRASHDIR"/configs
mv -f "$CRASHDIR"/configs/ShellClash.cfg "$CFG_PATH" 2>/dev/null
[ -f "$CFG_PATH" ] || echo '#ShellCrash配置文件，不明勿动！' >"$CFG_PATH"
if grep -qE '(^(clashcore|clash_v)=|=clash\.meta$|ShellClash|^cpucore=armv8$|^redir_mod=(Redir|Tproxy|Tun|混合|纯净)模式$|=(已启用|已开启|未启用|未开启)$)' "$CFG_PATH" 2>/dev/null; then
    sed -i "s/^clashcore=/crashcore=/" "$CFG_PATH"
    sed -i "s/^clash_v=/core_v=/" "$CFG_PATH"
    sed -i "s/=clash\.meta$/=meta/" "$CFG_PATH"
    sed -i "s/ShellClash/ShellCrash/g" "$CFG_PATH"
    sed -i "s/^cpucore=armv8$/cpucore=arm64/" "$CFG_PATH"
    sed -i "s/^redir_mod=Redir模式$/redir_mod=Redir/" "$CFG_PATH"
    sed -i "s/^redir_mod=Tproxy模式$/redir_mod=Tproxy/" "$CFG_PATH"
    sed -i "s/^redir_mod=Tun模式$/redir_mod=Tun/" "$CFG_PATH"
    sed -i "s/^redir_mod=混合模式$/redir_mod=Mix/" "$CFG_PATH"
    sed -i "s/^redir_mod=纯净模式$/firewall_area=4/" "$CFG_PATH"
    sed -i 's/=\(已启用\|已开启\)$/=ON/'  "$CFG_PATH"
    sed -i 's/=\(未启用\|未开启\)$/=OFF/' "$CFG_PATH"
fi
_init_had_cfg=0
_init_env_alias="$my_alias"
[ -s "$CFG_PATH" ] && grep -q '=' "$CFG_PATH" 2>/dev/null && _init_had_cfg=1
# 保留已有配置中的 my_alias 等字段，避免非交互升级时被空值或重新写盘覆盖
if [ "$_init_had_cfg" = 1 ]; then
    [ -z "$my_alias" ] && my_alias=$(awk -F= '$1=="my_alias"{v=$2} END{gsub(/^[\047"]|[\047"]$/,"",v); print v}' "$CFG_PATH" 2>/dev/null)
fi
#判断系统类型写入不同的启动文件
[ -w /usr/lib/systemd/system ] && sysdir=/usr/lib/systemd/system
[ -w /etc/systemd/system ] && sysdir=/etc/systemd/system
if [ -f /etc/rc.common -a "$(cat /proc/1/comm 2>/dev/null)" = "procd" ]; then
    #设为init.d方式启动
    cp -f "$CRASHDIR"/starts/shellcrash.procd /etc/init.d/shellcrash
    sed -i "s%/etc/ShellCrash%$CRASHDIR%g" /etc/init.d/shellcrash 2>/dev/null
    chmod 755 /etc/init.d/shellcrash
elif [ -n "$sysdir" ] && { [ "$(id -u 2>/dev/null)" = "0" ] || [ "$USER" = "root" ]; } && [ "$(cat /proc/1/comm 2>/dev/null)" = "systemd" ]; then
    #创建shellcrash用户
    userdel shellcrash 2>/dev/null
    sed -i '/^shellcrash:/d' /etc/passwd
    sed -i '/^shellcrash:/d' /etc/group
    if useradd -h >/dev/null 2>&1; then
        useradd shellcrash -u 7890 2>/dev/null
        sed -Ei 's/^(shellcrash:[^:]*:)7890:7890/\10:7890/' /etc/passwd
    else
        echo "shellcrash:x:0:7890::/home/shellcrash:/bin/sh" >>/etc/passwd
    fi
    #配置systemd
    _installed_systemd_unit="$sysdir/shellcrash.service"
    mv -f "$CRASHDIR"/starts/shellcrash.service "$_installed_systemd_unit" 2>/dev/null
    sed -i "s%/etc/ShellCrash%$CRASHDIR%g" "$_installed_systemd_unit"
    rm -rf "$CRASHDIR"/starts/shellcrash.procd
elif rc-status -r >/dev/null 2>&1; then
    #设为openrc方式启动
    mv -f "$CRASHDIR"/starts/shellcrash.openrc /etc/init.d/shellcrash
    sed -i "s%/etc/ShellCrash%$CRASHDIR%g" /etc/init.d/shellcrash 2>/dev/null
    chmod 755 /etc/init.d/shellcrash
    rm -rf "$CRASHDIR"/starts/shellcrash.procd
else
    #设为保守模式启动（不覆盖已有用户配置）
    grep -q '^start_old=' "$CFG_PATH" 2>/dev/null || setconfig start_old ON
    rm -rf "$CRASHDIR"/starts/shellcrash.procd
fi
rm -rf "$CRASHDIR"/starts/shellcrash.service
rm -rf "$CRASHDIR"/starts/shellcrash.openrc

#修饰文件及版本号（安全加固：缺省回退 sh，且仅替换第 1 行 shebang，不破坏脚本体内的 /bin/sh 引用）
shtype=sh
[ -x /bin/bash ] && shtype=bash
[ -x /bin/ash ] && shtype=ash
#批量授权
for file in start.sh starts/bfstart.sh starts/afstart.sh starts/fw_stop.sh starts/fw_ipv6_watch.sh menu.sh menus/task_cmd.sh menus/bot_tg.sh; do
    sed -i "1s|^#!/bin/sh\$|#!/bin/$shtype|" "$CRASHDIR/$file" 2>/dev/null
    chmod +x "$CRASHDIR/$file" 2>/dev/null
done
[ -s "$CRASHDIR"/version ] && version=$(head -n 1 "$CRASHDIR"/version | tr -d '\r\n ')
[ -n "$version" ] && setconfig versionsh_l "$version"
#证书策略迁移：旧配置只有 skip_cert=ON（原项目默认）且没有 node_tls 时，固化 node_tls=skip，
#保证升级后节点行为不变，之后单独修改"项目文件下载"开关也不会连带改变节点策略
if grep -qE "^skip_cert=['\"]?ON['\"]?\$" "$CFG_PATH" 2>/dev/null && ! grep -q '^node_tls=' "$CFG_PATH" 2>/dev/null; then
    setconfig node_tls skip
fi
#生成用于执行启动服务的变量文件
DIRECTORIES_FILE="$CRASHDIR"/configs/directories.env
COMMAND_FILE="$CRASHDIR"/configs/command.env
if [ ! -f "$DIRECTORIES_FILE" ]; then
    #迁移旧版中与启动命令混放的目录变量
    if [ -f "$COMMAND_FILE" ]; then
        . "$COMMAND_FILE"
    fi
    [ -z "$TMPDIR" ] && TMPDIR=/tmp/ShellCrash
    [ -z "$BINDIR" ] && BINDIR=$CRASHDIR
    printf 'TMPDIR=%s\nBINDIR=%s\n' "$TMPDIR" "$BINDIR" > "$DIRECTORIES_FILE"
    [ -f "$COMMAND_FILE" ] && sed -i '/^TMPDIR=.*/d; /^BINDIR=.*/d' "$COMMAND_FILE"
else
    . "$DIRECTORIES_FILE"
fi
[ -f "$COMMAND_FILE" ] || : > "$COMMAND_FILE"
if grep -qE "^(crashcore|clashcore)=['\"]?singbox" "$CFG_PATH" 2>/dev/null; then
    COMMAND='"$TMPDIR/CrashCore run -D $BINDIR -C $TMPDIR/jsons"'
    _systemd_exec="$TMPDIR/CrashCore run -D $BINDIR -C $TMPDIR/jsons"
else
    COMMAND='"$TMPDIR/CrashCore -d $BINDIR -f $TMPDIR/config.yaml"'
    _systemd_exec="$TMPDIR/CrashCore -d $BINDIR -f $TMPDIR/config.yaml"
fi
setconfig COMMAND "$COMMAND" "$COMMAND_FILE"
if [ -n "$_installed_systemd_unit" ] && [ -f "$_installed_systemd_unit" ]; then
    sed -i "s#^ExecStart=.*#ExecStart=$_systemd_exec#" "$_installed_systemd_unit"
    systemctl daemon-reload >/dev/null 2>&1 || true
fi
#设置防火墙执行模式
grep -q 'firewall_mod' "$CFG_PATH" 2>/dev/null || {
    firewall_mod=iptables
    nft add table inet shellcrash 2>/dev/null && firewall_mod=nftables
    setconfig firewall_mod $firewall_mod
}
#设置更新地址
[ -n "$url" ] && setconfig update_url "$url"
[ -n "$release_type" ] && setconfig release_type "$release_type"
#设置语言
[ -n "$language" ] && echo "$language" > "$CRASHDIR/configs/i18n.cfg"
#设置环境变量
[ -w /opt/etc/profile ] && [ "$systype" = "Padavan" ] && profile=/opt/etc/profile
[ -w /jffs/configs/profile.add ] && profile=/jffs/configs/profile.add
[ -z "$profile" ] && profile=/etc/profile
if [ -n "$profile" ]; then
    set_profile "$profile"
    #适配zsh环境变量
    zsh --version >/dev/null 2>&1 && [ -z "$(cat $HOME/.zshrc 2>/dev/null | grep CRASHDIR)" ] && set_profile "$HOME/.zshrc"
    if [ "$_init_had_cfg" = 0 ] || [ -n "$_init_env_alias" ]; then
        [ -n "$my_alias" ] && setconfig my_alias "$my_alias"
    fi
else
    echo -e "\033[33m无法写入环境变量！请检查安装权限！\033[0m"
    exit 1
fi
#梅林/Padavan额外设置
[ -n "$initdir" ] && {
    touch "$initdir"
    sed -i '/ShellCrash初始化/'d "$initdir"
    echo "$CRASHDIR/starts/general_init.sh & #ShellCrash初始化脚本" >>"$initdir"
    chmod 755 "$CRASHDIR"/starts/general_init.sh
    chmod a+rx "$initdir" 2>/dev/null
    setconfig initdir "$initdir"
}
#Padavan额外设置
[ -f "/etc/storage/started_script.sh" ] && mount -t tmpfs -o remount,rw,size=45M tmpfs /tmp #增加/tmp空间以适配新的内核压缩方式
#镜像化OpenWrt(snapshot)额外设置
if [ "$systype" = "mi_snapshot" -o "$systype" = "ng_snapshot" ]; then
    chmod 755 "$CRASHDIR"/starts/snapshot_init.sh
    if [ "$systype" = "mi_snapshot" ];then
        path="/data/shellcrash_init.sh"
        sed -i "s#^CRASHDIR=.*#CRASHDIR=$CRASHDIR#" "$CRASHDIR"/starts/snapshot_init.sh
        mv -f "$CRASHDIR"/starts/snapshot_init.sh "$path"
        [ ! -f /data/auto_start.sh ] && echo '#用于自定义需要开机启动的功能或者命令，会在开机后自动运行' > /data/auto_start.sh
    else
        path="$CRASHDIR"/starts/snapshot_init.sh
    fi
    uci delete firewall.auto_ssh 2>/dev/null
    uci delete firewall.ShellCrash 2>/dev/null
    uci set firewall.ShellCrash=include
    uci set firewall.ShellCrash.type='script'
    uci set firewall.ShellCrash.path="$path"
    uci set firewall.ShellCrash.enabled='1'
    uci commit firewall
else
    rm -rf "$CRASHDIR"/starts/snapshot_init.sh
fi
#华硕USB启动额外设置
[ "$usb_status" = "1" ] && {
    echo "$CRASHDIR/start.sh init & #ShellCrash初始化脚本" >"$CRASHDIR"/asus_usb_mount.sh
    nvram set script_usbmount="$CRASHDIR/asus_usb_mount.sh"
    nvram commit
}
#华硕下载大师启动额外设置
[ -f "$dir/asusware.arm/etc/init.d/S50downloadmaster" ] && [ -z "$(grep 'ShellCrash' $dir/asusware.arm/etc/init.d/S50downloadmaster)" ] &&
    sed -i "/^PATH=/a\\$CRASHDIR/start.sh init & #ShellCrash初始化脚本" "$dir/asusware.arm/etc/init.d/S50downloadmaster"
#容器环境额外设置（仅默认 /etc/ShellCrash 容器实例补充缺失项，避免沙箱测试或升级覆盖用户配置）
[ "$systype" = 'container' ] && [ "$CRASHDIR" = '/etc/ShellCrash' ] && {
    grep -q '^userguide=' "$CFG_PATH" 2>/dev/null || setconfig userguide '1'
    grep -q '^crashcore=' "$CFG_PATH" 2>/dev/null || setconfig crashcore 'meta'
    grep -q '^dns_mod=' "$CFG_PATH" 2>/dev/null || setconfig dns_mod 'mix'
    grep -q '^firewall_area=' "$CFG_PATH" 2>/dev/null || setconfig firewall_area '1'
    grep -q '^firewall_mod=' "$CFG_PATH" 2>/dev/null || setconfig firewall_mod 'nftables'
    grep -q '^release_type=' "$CFG_PATH" 2>/dev/null || setconfig release_type 'dev'
    grep -q '^start_old=' "$CFG_PATH" 2>/dev/null || setconfig start_old 'OFF'
    [ -w /etc/profile ] && { grep -qF "$CRASHDIR/menu.sh" /etc/profile 2>/dev/null || echo "$CRASHDIR/menu.sh" >> /etc/profile; }
    [ -w /usr/bin ] && {
        cat > /usr/bin/crash <<'EOF'
#!/bin/sh
CRASHDIR=${CRASHDIR:-/etc/ShellCrash}
export CRASHDIR
exec "$CRASHDIR/menu.sh" "$@"
EOF
        chmod 755 /usr/bin/crash
    }
}
[ -n "$systype" ] && { [ "$_init_had_cfg" = 0 ] || grep -q '^systype=' "$CFG_PATH" 2>/dev/null; } && setconfig systype "$systype"
#删除临时文件
rm -rf /tmp/*rash*gz
rm -rf /tmp/SC_tmp
#转换&清理旧版本文件
mkdir -p "$CRASHDIR"/yamls
mkdir -p "$CRASHDIR"/jsons
mkdir -p "$CRASHDIR"/tools
mkdir -p "$CRASHDIR"/task
mkdir -p "$CRASHDIR"/ruleset
for file in config.yaml.bak user.yaml proxies.yaml proxy-groups.yaml rules.yaml others.yaml; do
    mv -f "$CRASHDIR"/"$file" "$CRASHDIR"/yamls/"$file" 2>/dev/null
done
[ ! -L "$CRASHDIR"/config.yaml ] && mv -f "$CRASHDIR"/config.yaml "$CRASHDIR"/yamls/config.yaml 2>/dev/null
for file in fake_ip_filter mac web_save servers_chs.list servers_en.list fake_ip_filter.list dns_direct_domains.list singbox_providers.list clash_providers.list; do
    mv -f "$CRASHDIR"/"$file" "$CRASHDIR"/configs/"$file" 2>/dev/null
done
#迁移任务状态文件到新目录
for file in cron bfstart afstart running affirewall task.user; do
    mv -f "$CRASHDIR"/"$file" "$TASKCFGDIR"/"$file" 2>/dev/null
    mv -f "$CRASHDIR"/task/"$file" "$TASKCFGDIR"/"$file" 2>/dev/null
done
#修正旧版防火墙注入路径
for file in /etc/init.d/firewall /etc/init.d/firewall.bak; do
    [ -f "$file" ] && sed -i "s#$CRASHDIR/task/affirewall#$TASKCFGDIR/affirewall#g" "$file" 2>/dev/null
done
#数据库改名
mv -f "$CRASHDIR"/geosite.dat "$CRASHDIR"/GeoSite.dat 2>/dev/null
mv -f "$CRASHDIR"/ruleset/geosite-cn.srs "$CRASHDIR"/ruleset/cn.srs 2>/dev/null
mv -f "$CRASHDIR"/ruleset/geosite-cn.mrs "$CRASHDIR"/ruleset/cn.mrs 2>/dev/null
#数据库移动
mv -f "$CRASHDIR"/*.srs "$CRASHDIR"/ruleset/ 2>/dev/null
mv -f "$CRASHDIR"/*.mrs "$CRASHDIR"/ruleset/ 2>/dev/null
for file in dropbear_rsa_host_key authorized_keys tun.ko ShellDDNS.sh; do
    mv -f "$CRASHDIR"/"$file" "$CRASHDIR"/tools/"$file" 2>/dev/null
done
for file in cron task_chs.list task_en.list; do
    mv -f "$CRASHDIR"/"$file" "$CRASHDIR"/task/"$file" 2>/dev/null
done
mv -f "$CRASHDIR"/menus/task_cmd.sh "$CRASHDIR"/task/task.sh 2>/dev/null
#旧版文件清理
userdel shellclash >/dev/null 2>&1
[ -w /etc/passwd ] && grep -q 'shellclash' /etc/passwd 2>/dev/null && sed -i '/shellclash/d' /etc/passwd
[ -w /etc/group ] && grep -q 'shellclash' /etc/group 2>/dev/null && sed -i '/shellclash/d' /etc/group
rm -rf /etc/init.d/clash
rm -rf "$CRASHDIR"/rules
[ "$systype" = "mi_snapshot" -a "$CRASHDIR" != '/data/clash' ] && rm -rf /data/clash
for file in webget.sh misnap_init.sh core.new configs/ShellCrash.cfg.bak; do
    rm -f "$CRASHDIR/$file"
done

printf '\033[32m脚本初始化完成,请输入\033[30;47m %s \033[0;33m命令开始使用！\033[0m\n' "$my_alias"

# 兼容旧版(如 1.9.6alpha1)菜单更新直接 source init.sh 且未重启服务的行为：若升级前核心在运行($PID 非空)则自动拉起并校验
if [ -z "$_SC_UPG_ACTIVE" ] && [ -n "$__IS_MODULE_9_UPGRADE_LOADED" ] && [ -n "$PID" ]; then
    "$CRASHDIR"/start.sh start || exit 1
fi
