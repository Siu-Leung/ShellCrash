
# 检查配置文件
[ -z "$TASKCFGDIR" ] && TASKCFGDIR="$CRASHDIR"/configs/task
[ -f "$CRASHDIR"/configs/ShellCrash.cfg ] || . "$CRASHDIR"/init.sh >/dev/null 2>&1
[ -f "$CRASHDIR"/configs/directories.env ] && . "$CRASHDIR"/configs/directories.env >/dev/null 2>&1
. "$CRASHDIR"/configs/command.env >/dev/null 2>&1
. "$CRASHDIR"/configs/ShellCrash.cfg

[ -z "$mix_port" ] && mix_port=7890
[ -z "$redir_port" ] && redir_port=7892
[ -z "$tproxy_port" ] && tproxy_port=7893
[ -z "$db_port" ] && db_port=9999
[ -z "$dns_port" ] && dns_port=1053
[ -z "$dns_redir_port" ] && dns_redir_port="$dns_port"
[ -z "$fwmark" ] && fwmark="$redir_port"
routing_mark=$((fwmark + 2))
[ -z "$table" ] && table=100

[ -z "$fakeip4" ] && fakeip4="198.18.0.0/15"
[ -z "$fakeip6" ] && fakeip6="2001:2::/64"

[ -z "$dns_nameserver" ] && {
    dns_nameserver='223.5.5.5, 1.2.4.8'
    netstat -ntlup 2>/dev/null | grep -q '127.0.0.1:53' || ss -ntlup 2>/dev/null | grep -q '127.0.0.1:53' && dns_nameserver='127.0.0.1'
}
[ -z "$dns_fallback" ] && dns_fallback="1.1.1.1, 8.8.8.8"
[ -z "$dns_resolver" ] && dns_resolver="223.5.5.5, 2400:3200::1"
[ -z "$dns_proxy_server" ] && dns_proxy_server="$dns_resolver"
