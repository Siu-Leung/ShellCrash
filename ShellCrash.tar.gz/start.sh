#!/bin/sh
# Copyright (C) Juewuy

#初始化目录
[ -z "$CRASHDIR" ] && CRASHDIR=$(
    cd $(dirname $0)
    pwd
)
. "$CRASHDIR"/libs/set_cron.sh
croncheck || exit 1
. "$CRASHDIR"/libs/get_config.sh
#加载工具
. "$CRASHDIR"/libs/set_config.sh
. "$CRASHDIR"/libs/check_cmd.sh
. "$CRASHDIR"/libs/check_autostart.sh
. "$CRASHDIR"/libs/compare.sh
. "$CRASHDIR"/libs/logger.sh
. "$CRASHDIR"/libs/web_save.sh
#特殊脚本
bfstart(){
    "$CRASHDIR"/starts/bfstart.sh
}
afstart(){
    "$CRASHDIR"/starts/afstart.sh
}
stop_firewall(){
    "$CRASHDIR"/starts/fw_stop.sh
}
start_firewall(){
    . "$CRASHDIR"/starts/fw_start.sh
}
is_root_user() {
    [ "$(id -u 2>/dev/null)" = "0" ] || [ "$USER" = "root" ]
}
#保守模式启动
start_l(){
    bfstart && {
        . "$CRASHDIR"/starts/start_legacy.sh
        start_legacy "$COMMAND" 'shellcrash'
    } && afstart &
}

case "$1" in

start)
    if [ -n "$(pidof CrashCore)" ]; then #禁止多实例
        "$0" stop || exit 1
    fi
    stop_firewall                          #清理路由策略
    rm -f "$CRASHDIR"/\.start_error #移除自启失败标记
    #使用不同方式启动服务
    if [ "$firewall_area" = "5" ]; then #主旁转发
        . "$CRASHDIR"/starts/fw_start.sh
    elif [ "$start_old" = "ON" ]; then
        start_l
    elif [ -f /etc/rc.common ] && grep -q 'procd' /proc/1/comm; then
        /etc/init.d/shellcrash start
    elif is_root_user && grep -q 'systemd' /proc/1/comm; then
        FragmentPath=$(systemctl show -p FragmentPath shellcrash | sed 's/FragmentPath=//')
        [ -f "$FragmentPath" ] && {
            sed -i "s#^ExecStart=.*#ExecStart=$COMMAND >/dev/null#" "$FragmentPath"
            systemctl daemon-reload
        }
        systemctl start shellcrash.service || . "$CRASHDIR"/starts/start_error.sh
    elif grep -q 's6' /proc/1/comm; then
        bfstart && /command/s6-svc -u /run/service/shellcrash && {
            [ ! -f "$CRASHDIR"/.dis_startup ] && enable_s6_autostart_marks
            afstart &
        }
    elif rc-status -r >/dev/null 2>&1; then
        rc-service shellcrash stop >/dev/null 2>&1
        rc-service shellcrash start
    else
        start_l
    fi
    ;;
stop)
    logger ShellCrash服务即将关闭......
    [ -n "$(pidof CrashCore)" ] && web_save #保存面板配置
    #清理定时任务
    cronupdate awk 'NF && !/start_legacy_wd.sh|运行时每/' || exit 1
    #停止tg_bot
    . "$CRASHDIR"/menus/bot_tg_service.sh && bot_tg_stop
    #多种方式结束进程
    if [ -f "$TMPDIR/shellcrash.pid" ];then
        kill -TERM "$(cat "$TMPDIR/shellcrash.pid")" 2>/dev/null
        rm -f "$TMPDIR/shellcrash.pid"
        stop_firewall
    elif is_root_user && grep -q 'systemd' /proc/1/comm; then
        systemctl stop shellcrash.service >/dev/null 2>&1
    elif [ -f /etc/rc.common ] && grep -q 'procd' /proc/1/comm; then
        /etc/init.d/shellcrash stop >/dev/null 2>&1
    elif grep -q 's6' /proc/1/comm; then
        /command/s6-svc -d /run/service/shellcrash
        stop_firewall
    elif rc-status -r >/dev/null 2>&1; then
        rc-service shellcrash stop >/dev/null 2>&1
    else
        stop_firewall
    fi
    killall CrashCore 2>/dev/null
    #清理缓存目录
    rm -rf "$TMPDIR"/CrashCore
    ;;
restart)
    "$0" stop && "$0" start
    ;;
init)
    . "$CRASHDIR"/starts/general_init.sh
    ;;
daemon)
    if [ -f "$TMPDIR"/crash_start_time ]; then
        "$0" start
    else
        sleep 60 && touch "$TMPDIR"/crash_start_time
    fi
    ;;
debug)
    if [ -n "$(pidof CrashCore)" ]; then #禁止多实例
        "$0" stop >/dev/null || exit 1
    fi
    stop_firewall >/dev/null                          #清理路由策略
    bfstart
    if [ -n "$2" ]; then
        case "$2" in
            debug|info|warning|warn|error|silent|fatal|panic|trace) _dbg_lvl="$2" ;;
            *) _dbg_lvl="debug" ;;
        esac
        if echo "$crashcore" | grep -q 'singbox'; then
            sed -i "s/\"level\": \"info\"/\"level\": \"$_dbg_lvl\"/" "$TMPDIR"/jsons/log.json 2>/dev/null
        else
            sed -i "s/log-level: info/log-level: $_dbg_lvl/" "$TMPDIR"/config.yaml
        fi
        [ "$3" = flash ] && dir="$CRASHDIR" || dir="$TMPDIR"
        $COMMAND >"$dir"/debug.log 2>&1 &
        sleep 2
        logger "已运行debug模式!如需停止，请使用重启/停止服务功能！" 33
    else
        $COMMAND >/dev/null 2>&1 &
    fi
    afstart
    ;;
bfstart)
    bfstart
    ;;
afstart)
    afstart
    ;;
stop_firewall)
    stop_firewall
    ;;
start_firewall)
    start_firewall
    ;;
cronset)
    cronset "$2" "$3"
    ;;
*)
    echo "Unsupported start.sh command: $1" >&2
    exit 1
    ;;

esac
